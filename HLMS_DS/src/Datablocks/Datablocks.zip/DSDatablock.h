/*
 * DSDatablock.h
 *
 *  Created on: 24.11.2015
 *      Author: marvin
 */
#include "math.h"

#ifndef DATABLOCKS_DSDATABLOCK_H_
#define DATABLOCKS_DSDATABLOCK_H_
#include "../OgreHlmsDSPrerequisites.h"
#include "OgreHlmsDatablock.h"
#include "OgreHlmsTextureManager.h"
#include "OgreConstBufferPool.h"
#include "OgreHeaderPrefix.h"
#include "Data/DSPropertyParam.h"
#include "Data/DSPieceParam.h"
#include "AutoParams/DSAutoTime.h"
#include "AutoParams/DSAutoParamParser.h"
#include "Data/DSShadowParam.h"
#include "Data/DSShadowTexture.h"

namespace Ogre {
class HlmsDS;
class DSTextureParamType;
class DSVec4ParamType;

class DSTextureParam;
class DSMaterialParam;

class DSDatablock : public HlmsDatablock {
public:
	std::vector<DSTextureParamType> *textureParamTypes;
	std::vector<DSVec4ParamType> *vec4ParamTypes;
	std::vector<DSPropertyParamType> *propertyParamTypes;
	std::vector<DSPieceParamType> *pieceParamTypes;

	std::vector<DSTextureParam> *textureParams;
	std::vector<DSPropertyParam> *propertyParams;
	std::vector<DSMaterialParam * > *materialParams;
	std::vector<DSPieceParam> *pieceParams;

	//std::vector<DSAutoParam*> *autoParams;

	std::vector<DSPropertyParam>  check;


	Ogre::ColourValue* IDColour;

	DSAutoParamParser * parser;

    static const size_t MaterialSizeInGpu;
    static const size_t MaterialSizeInGpuAligned;


    //default Values for now (14 Textures+4 vec4)
    static const size_t MaxVec4Params=4;
    static const size_t MaxTextureParams=4;



	enum DSTextureType {
		DS_TEXTURE_DIFFUSE,
		DS_TEXTURE_NORMAL,
		DS_TEXTURE_SPECULAR,
		DS_TEXTURE_GLOW,
		DS_TEXTURE_OPACITY,
		DS_TEXTURE_REFLECTION,

		DS_TEXTURE_CUSTOM,


		NUM_DS_TEXTURE_TYPES
	};
	enum DSDATABLOCKTYPE {
		DS_DATABLOCK_BASE,
		DS_DATABLOCK_MATERIAL,
		DS_DATABLOCK_LIGHT,
		DS_DATABLOCK_FORWARD,

		NUM_DS_DATABLOCK_TYPES
	} dbtype;
//
    struct DSBakedTexture
    {

        TexturePtr              texture;
        HlmsSamplerblock const *samplerBlock;

        //kinda hacky but I hate hardcoding texturetypes

        DSBakedTexture() : samplerBlock( 0 ) {}
        DSBakedTexture( const TexturePtr tex, const HlmsSamplerblock *_samplerBlock ) :
            texture( tex ), samplerBlock( _samplerBlock ) {}

        bool operator == ( const DSBakedTexture &_r ) const
        {
            return texture == _r.texture && samplerBlock == _r.samplerBlock;
        }
    };
    typedef FastArray<DSBakedTexture> DSBakedTexturesArray;



    int TextureSize;





    uint16  mTexIndices[NUM_DS_TEXTURE_TYPES];




   // can't use Const Buffer Pool
    ConstBufferPacked* MaterialBuffer;
    ConstBufferPacked* ShadowMaterialBuffer;

    DSBakedTexturesArray mBakedTextures;
    /// The way to read this variable is i.e. get diffuse texture,
    /// mBakedTextures[mTexToBakedTextureIdx[PBSM_DIFFUSE]]
    /// Then read mTexIndices[PBSM_DIFFUSE] to know which slice of the texture array.
    uint8   mTexToBakedTextureIdx[NUM_DS_TEXTURE_TYPES];

    HlmsSamplerblock const  *mSamplerblocks[NUM_DS_TEXTURE_TYPES];

    /// Sets the appropiate mTexIndices[textureType], and returns the texture pointer
    HlmsTextureManager::TextureLocation setTexture( const String &name, DSTextureType textureType ,DSTextureParam*paramtype);

	DSDatablock(IdString name, HlmsDS *creator,
	        const HlmsMacroblock *macroblock,
	        const HlmsBlendblock *blendblock,
	        const HlmsParamVec &params ,bool derived=false );
	virtual ~DSDatablock();
	float randf();
	float randf2();

	enum Status{
		CLEAN,
		DIRTY,
		BROKEN
	};

	Status status;

	bool staticMaterial=true;

	Ogre::Vector3  randv();
	Ogre::Vector3  randv2();
	Ogre::Vector3  randv3();
     void markForUpdate();
     void syncWithGPU();
    void bakeTextures( const DSBakedTexture textures[NUM_DS_TEXTURE_TYPES] );
//    void bakeTextures();

    bool UpdateAllowed=false;


    void frameEnded();

    void createConstBuffer(HlmsDS *creator);
    ConstBufferPacked *getMaterialBuffer();


    size_t getMaterialBufferSize();

     void calculateHash();

   virtual void initializeParamTypes();

    void initParam(String paramVal,DSMaterialParam* param);
    void initTextureUnit(String paramVal,DSTextureParamType * type,HlmsManager *hlmsManager);



    void setData(const HlmsParamVec &params);

    void setParam(Ogre::String, Ogre::String);
    void setParam(Ogre::String, Ogre::Vector4);
    void setParam(Ogre::String, float);

    const Ogre::Vector4* const getParam(Ogre::String);

    float * getAutoParam(uint id);

    void initializeMaterial(const HlmsParamVec &params, HlmsDS *creator);

    virtual void initializeProperties();
    virtual void setProperties();


    void syncShadowParams();
    void generateShadowParams();
    bool isDirty();

    void createTexIndexPropertys(bool caster);
    void createVec4IndexPropertys(bool caster);

	std::vector<DSPropertyParam>* getPropertyParams(){
		return propertyParams;
	}
	std::vector<DSPieceParam>* getPieceParams(){
		return pieceParams;
	}

	Status getStatus() const;
	void setStatus(Status status);

};

} /* namespace Ogre */

#endif /* DATABLOCKS_DSDATABLOCK_H_ */
