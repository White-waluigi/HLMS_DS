/*
 * DSMaterialParam.cpp
 *
 *  Created on: Aug 18, 2016
 *      Author: marvin
 */

#include <Datablocks/Data/DSMaterialParam.h>
#include "OgreException.h"
#include "DSVec4ParamType.h"

namespace Ogre {

Ogre::String DSMaterialParam::defaultDatatypes[(int)(CUSTOM)]={"float","vec4","mat4","uint","uvec4"};


float* DSMaterialParam::getData() const {
	return data;
}

DSMaterialParam::DSMaterialParam(float* data, DSMType type, bool array,
		size_t arraySize) {
	this->data=new float[getSize()];
	this->type=type;
	if(array){
		this->array=array;
		this->arraySize=arraySize;

	}
}

size_t DSMaterialParam::getSize() {
	size_t size;
	if(this->type==SINGLEFLOAT){
		//Can't be smaller than 0
		size=4;
	}else
	{}
	switch(this->type){
	case SINGLEFLOAT: size=4;break;
	case VEC4: size=4;break;

	case MAT4: size=16;break;

	case CUSTOM:size=getCustomSize();break;


	}
	return size*arraySize;
}


void DSMaterialParam::map(GPUPointer* pointer) {
	pointer->map(this->data,getSize());
}

void DSMaterialParam::update() {
}

size_t DSMaterialParam::getCustomSize() {
	throw Ogre::Exception(Ogre::Exception::ERR_INTERNAL_ERROR,"Error, must implement update for getSize for custom datatype!","DSMaterialParam::getSize");
}

void DSMaterialParam::setData(float* data) {
	this->data = data;
}

DSMaterialParam::~DSMaterialParam() {
	// TODO Auto-generated destructor stub
}

} /* namespace Ogre */

const Ogre::String& Ogre::DSMaterialParam::getParamName() const {
	return paramName;
}

void Ogre::DSMaterialParam::setParamName(const Ogre::String& paramName) {
	this->paramName = paramName;
}

const Ogre::String& Ogre::DSMaterialParam::getPostFix() const {
	return postFix;
}

int Ogre::DSMaterialParam::getNumVec() const {
	return numVec;
}

void Ogre::DSMaterialParam::setNumVec(int numVec) {
	this->numVec = numVec;
}

void Ogre::DSMaterialParam::setPostFix(const Ogre::String& postFix) {
	this->postFix = postFix;
}

Ogre::DSMaterialParam::DSMaterialParam() {
}

Ogre::DSMaterialParam::DSMaterialParam(Ogre::DSVec4ParamType* type) {
	this->postFix=type->postFix;
	this->numVec=type->numVec;
	this->paramName=type->paramName;
	this->defaultVal=type->defaultVal;

}

void Ogre::DSMaterialParam::initialize(const HlmsParamVec& params) {
}

Ogre::String Ogre::DSMaterialParam::getParamString(int index) {

	Ogre::String datatype;


	if(!(type==CUSTOM)){
		datatype=defaultDatatypes[type];
	}else {
		throw Ogre::Exception(Ogre::Exception::ERR_INTERNAL_ERROR,"Error, must implement getParamString if custom Datatype is used!","DSAutoParam::getParamString");
	}

	stringstream s;
	int i;

	s << index;

	Ogre::String converted(s.str());

	return datatype+" autoparam"+ converted+";";


}
