/*
 * DSTextureParam.cpp
 *
 *  Created on: 03.03.2016
 *      Author: marvin
 */

#include "DSTextureParam.h"
#include "DSTextureParamType.h"
namespace Ogre {

DSTextureParam::DSTextureParam(DSTextureParamType* type) {
	// TODO Auto-generated constructor stub
	this->PostFix = type->postFix;
	this->textureType = type->textureType;
	this->samplerBlock = type->samplerBlock;

	this->anim_timer = new Timer();

}

DSTextureParam::~DSTextureParam() {
	// TODO Auto-generated destructor stub
}

const Ogre::String& Ogre::DSTextureParam::getPostFix() const {
	return PostFix;
}

DSDatablock::DSTextureType Ogre::DSTextureParam::getTextureType() const {
	return textureType;
}

void Ogre::DSTextureParam::setTextureType(
		DSDatablock::DSTextureType textureType) {
	this->textureType = textureType;
}

void Ogre::DSTextureParam::setPostFix(const Ogre::String& postFix) {
	PostFix = postFix;
}

int Ogre::DSTextureParam::getUVindex() const {
	return UVindex;
}

bool DSTextureParam::isDynamic() const {
	return dynamic;
}

int DSTextureParam::getNumTextures() {
	return texture.size();
}

DSDatablock::DSBakedTexture* DSTextureParam::getActiveTexture() {
	if (!isMultiTex()) {
		return getTexture(0);
	}
}

uvec2* DSTextureParam::getActiveLocation() {
	if (!isMultiTex()) {
		return getLocation(0);
	}
		return getLocation(active_anim);

}

bool DSTextureParam::isMultiTex() {
	return getNumTextures() > 1;
}

int DSTextureParam::getAnimInterval() const {
	return anim_interval;
}

void DSTextureParam::setAnimInterval(int animInterval) {
	anim_interval = animInterval;
}

bool DSTextureParam::isAnimatedTexture() const {
	return animatedTexture||animatedUV;
}

void DSTextureParam::setAnimatedTexture(bool animatedTexture) {
	this->animatedTexture = animatedTexture;
	this->setDynamic(true);

}

int DSTextureParam::getMaxAnim() const {
	return max_anim;
}

Matrix4 DSTextureParam::getTextMat() const {
	return anim_texMat*stat_texMat;
}

void DSTextureParam::setTextMat(Matrix4 textMat) {
	this->stat_texMat = textMat;
}

void DSTextureParam::setMaxAnim(int maxAnim) {
	max_anim = maxAnim;
}

void DSTextureParam::setDynamic(bool dynamic) {
	this->dynamic = dynamic;
}

DSDatablock::DSBakedTexture* DSTextureParam::getTexture(int i) {
	assert(i < texture.size());
	return texture.at(i);
}

uvec2 *DSTextureParam::getLocation(int i) {
	return texLocation.at(i);
}

void DSTextureParam::addTexture(HlmsTextureManager::TextureLocation* texloc) {
	uvec2 *vec = new uvec2(texloc->yIdx, texloc->xIdx);

	this->texLocation.push_back(vec);

	DSDatablock::DSBakedTexture* bakedtex = new DSDatablock::DSBakedTexture();
	bakedtex->texture = texloc->texture;
	bakedtex->samplerBlock = &getSamplerBlock();

	this->texture.push_back(bakedtex);
}

void Ogre::DSTextureParam::setUVindex(int vindex) {
	UVindex = vindex;
}
bool Ogre::DSTextureParam::update() {
	long cur = anim_timer->getMicroseconds()/1000;

	if (animatedTexture) {
		if ((cur - anim_elapsed) > anim_interval) {
			anim_elapsed = cur;
			active_anim++;
			active_anim %= max_anim;
		}
	}

	if(animatedUV){

		float v=fmod(cur/1000.0,(anim.transt));

		this->anim_texMat=Matrix4::IDENTITY;
		//this->textMat.setTrans(Vector3(v,0 ,0));
		this->anim_texMat.setTrans(Vector3(v*anim.trans.x,v*anim.trans.y ,1));

	}




}
bool DSTextureParam::isAnimatedUv() const {
	return animatedUV;
}

void DSTextureParam::setAnimatedUv(bool animatedUv) {
	animatedUV = animatedUv;
	this->setDynamic(true);

}
} /* namespace Ogre */


