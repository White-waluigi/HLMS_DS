/*
 * DSPieceParam.cpp
 *
 *  Created on: 26.03.2016
 *      Author: marvin
 */

#include "DSPieceParam.h"
#include "DSPieceParamType.h"
#include "OgreString.h"
namespace Ogre {


DSPieceParam::DSPieceParam(String a, String b,DSPieceParamType * type) {
	this->id=IdString(a);
	this->piece=b;
	this->parent=type;
	this->shader=type->shader;
}
DSPieceParam::~DSPieceParam() {
	// TODO Auto-generated destructor stub
}

} /* namespace Ogre */

 Ogre::IdString& Ogre::DSPieceParam::getId()  {
	return id;
}

void Ogre::DSPieceParam::setId( IdString& id) {
	this->id = id;
}

 Ogre::DSPieceParamType*& Ogre::DSPieceParam::getParent()  {
	return parent;
}

void Ogre::DSPieceParam::setParent( DSPieceParamType*& parent) {
	this->parent = parent;
}

 Ogre::String& Ogre::DSPieceParam::getPiece()  {
	return piece;
}

void Ogre::DSPieceParam::setPiece( String& piece) {
	this->piece = piece;
}

int Ogre::DSPieceParam::getShader() const {
	return shader;
}

void Ogre::DSPieceParam::setShader(int shader) {
	this->shader = shader;
}
