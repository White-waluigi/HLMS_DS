/*
 * DSShadowParam.cpp
 *
 *  Created on: Jul 9, 2016
 *      Author: marvin
 */

#include "DSShadowParam.h"

namespace Ogre {

DSShadowParam::DSShadowParam(String name) {
	this->name=name;
}

DSShadowParam::~DSShadowParam() {
	// TODO Auto-generated destructor stub
}

} /* namespace Ogre */
