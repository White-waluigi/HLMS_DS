/*
 * DSVec4ParamType.cpp
 *
 *  Created on: 03.03.2016
 *      Author: marvin
 */

#include "DSVec4ParamType.h"

namespace Ogre {

DSVec4ParamType::DSVec4ParamType() {
	// TODO Auto-generated constructor stub

}

DSVec4ParamType::~DSVec4ParamType() {
	// TODO Auto-generated destructor stub
}

} /* namespace Ogre */
//test55
