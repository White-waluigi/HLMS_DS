/*
 * DSVec4ParamType.h
 *
 *  Created on: 03.03.2016
 *      Author: marvin
 */

#ifndef SRC_DATABLOCKS_DATA_DSVEC4PARAMTYPE_H_
#define SRC_DATABLOCKS_DATA_DSVEC4PARAMTYPE_H_
#include "OgreString.h"
#include "OgreVector4.h"
namespace Ogre {

class DSVec4ParamType {
public:
	Ogre::String paramName;
	int numVec;

	Ogre::String postFix;
	Ogre::Vector4 defaultVal=Vector4(0,0,0,0);
	DSVec4ParamType();
	virtual ~DSVec4ParamType();

};

} /* namespace Ogre */

#endif /* SRC_DATABLOCKS_DATA_DSVEC4PARAMTYPE_H_ */
