/*
 * DSShadowTexture.cpp
 *
 *  Created on: Jul 9, 2016
 *      Author: marvin
 */

#include "DSShadowTexture.h"

namespace Ogre {

DSShadowTexture::DSShadowTexture(String name) {
	this->name=name;
}

DSShadowTexture::~DSShadowTexture() {
	// TODO Auto-generated destructor stub
}

} /* namespace Ogre */
