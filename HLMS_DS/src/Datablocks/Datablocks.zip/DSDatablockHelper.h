/*
 * DSDatablockHelper.h
 *
 *  Created on: Jul 15, 2016
 *      Author: marvin
 */

#ifndef SRC_DATABLOCKS_DSDATABLOCKHELPER_H_
#define SRC_DATABLOCKS_DSDATABLOCKHELPER_H_

namespace Ogre {

class DSDatablockHelper {
public:
	DSDatablockHelper();
	virtual ~DSDatablockHelper();

};

} /* namespace Ogre */

#endif /* SRC_DATABLOCKS_DSDATABLOCKHELPER_H_ */
