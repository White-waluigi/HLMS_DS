/*
 * DSDatablockHelper.cpp
 *
 *  Created on: Jul 15, 2016
 *      Author: marvin
 */

#include "DSDatablockHelper.h"

namespace Ogre {

DSDatablockHelper::DSDatablockHelper() {
	// TODO Auto-generated constructor stub

}

DSDatablockHelper::~DSDatablockHelper() {
	// TODO Auto-generated destructor stub
}

} /* namespace Ogre */
